package com.app.tictactoe;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.io.IOException;
import java.net.URI;
import java.util.Scanner;

/**
 * Class TicTacTorStarter
 * Methods:startServer, main
 */
public class TicTacToeStarter {
    // Base URI the Grizzly HTTP server will listen on
    public static final String BASE_URI = "http://0.0.0.0:8080/application/";

    /**
     * Starts Grizzly HTTP server exposing JAX-RS resources defined in this application.
     *
     * @return Grizzly HTTP server.
     */
    public static HttpServer startServer() {
        // resource config that scans for JAX-RS resources and providers in in the package specified
        final ResourceConfig rc = new ResourceConfig().packages("com.app.tictactoe");

        // create and start a new instance of grizzly http server
        // exposing the Jersey application at BASE_URI
        return GrizzlyHttpServerFactory.createHttpServer(URI.create(BASE_URI), rc);
    }

    public static void main(String[] args) throws IOException {
        final HttpServer server = startServer();
        System.out.println(String.format("Tic Tac Toe application is Up @ URI:%sapplication.wadl\n Hit X or x to stop the application...", BASE_URI));
        //System.in.read();
        Scanner sc=new Scanner(System.in);
        String exitChar="";
        while(sc.hasNext())
        {
        exitChar=sc.next();
        if("X".equals(exitChar) || "x".equals(exitChar))
        server.stop();
        }
    }
}

